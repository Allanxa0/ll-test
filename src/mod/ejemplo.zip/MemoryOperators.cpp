// This file will make your mod use LeviLamina's memory operators by default.
// This improves the memory management of your mod and is recommended to use.

#define LL_MEMORY_OPERATORS

#include "ll/api/memory/MemoryOperators.h" // IWYU pragma: keep
